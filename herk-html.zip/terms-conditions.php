<!DOCTYPE HTML>
<html>
<head>
<title>HERK-Terms &amp; Conditions</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/scrolling-slider-data.css">
<link rel="stylesheet" href="style.css"/>

    <script>
        $(document).ready(function(){
            
            $(".retailer-container").css({"width":"50px"});
            $(".show-retailer").click(function(){
                $(".retailer-container").animate({
                    "width":"790"
                }, 200);
                $(".retailer-container form").show();
                $("#btn-close").show();
            });
            $("#btn-close").click(function(){
                $(".retailer-container form").hide();
                $(".retailer-container").animate({
                    "width":"50px"
                }, 200);
                $(this).hide();
            });
            
		});
    </script>
    
</head>
<body>
<div class="page-container">
    
    <div class="retailer-container page-home">
        <h5 class="show-retailer">BECOME A RETAILER</h5>
        <div id="btn-close">X</div>
        <form>
            <ul>
                <li><input type="text" placeholder="* Name" /></li>
                <li><input type="email" placeholder="* Email" /></li>
                <li><input type="text" placeholder="* Company Name" /></li>
                <li><input class="col-sm-6" type="email" placeholder="* Phone" />
                <input class="col-sm-6" type="email" placeholder="* Location" /></li>
                
                <li><textarea placeholder="* Comments" ></textarea></li>
                <li><div class="default-button text-right"><input value="SUBMIT" type="submit"></div></li>
            </ul>
        </form>
    </div>
    
<!--start header-->
    <div class="container-fluid pd-0">
        
        <script>
            $(document).ready(function(){
                $(".search-top").click(function(){
                    $("#search-box").toggle();
                });
            });
        </script>
        <ul class="pull-right top-nav">
            <li><input id="search-box" type="text"/></li>
            <li class="search-top"><a href="#"><img src="images/search-icon-small.png"/></a></li>
            <li><a href="#"><img src="images/mail-icon-small.png"/></a></li>
            <li><a href="#"><img src="images/user-icon-small.png"/></li>
            <li><a href="#"><img src="images/basket-icon-small.png"/> <sup>0</sup></a></li>
        </ul>
        
    </div>
    <div class="container-fluid pd-0 menu-container">
        
        <div class="logo"><a href="index.php"><img src="images/logo-black.png"/></a></div>
        <div class="main-menu">
            <ul class="menu">
                <li><a href="#">SHOP</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="contact.php">CONTACT</a></li>
                <li><a href="stockists.php">STOCKISTS</a></li>
            </ul>
        </div>
    </div>
<!--end header-->
    <div class="clearfix"></div>
    
    
        <div class="default-container1 rel">
            <h1 class="terms-rotate">TERMS + CONDITIONS</h1>
            <div class="shipping-policy terms">
                <p class="head">Our goods come with guarantees that cannot be excluded under the australian consumer law.</p>
                
                <ul class="policy-list">
                    <li>You are entitled to a replacement or refund for a major failure and compensation for any other reasonably forseeable loss or damage.</li>
                    <li>You are also entitled to have the goods repaired or replaced if the goods fail to be of acceptable quality and the failure does not amount to major failure.</li>
                    <li>This warranty will be for a period of 3 months from the date of purchase of the item.</li>
                    <li>This warranty is only only against a defect on the item. It does not cover damage caused by fair wear and tear, incorrect usage, deliberate damage or accident or modification.</li>
                    <li>To claim against this warrranty, you must return the item purchased to us with a valid receipt or other proof of purchase.</li>
                    <li>The item and receipt must be returned to:</li>
                    <li>Herk Accessories Pty Ltd<br>Suite 2, Level 3, 426 King Street<br>Newcastle West, 2302 NSW.</li>
                </ul>
            </div>
        </div>
    
    
    
    
    <div class="clearfix"></div>
    <footer>
        <div class="container-fluid news-letter pd-0">
            <div class="default-container">
            <div class="row mrg-0">
                <p>SIGN UP TO OUR NEWSLETTER</p>
                <form>
                    <div class="col-sm-6">
                        <input type="text" placeholder="* Name"/>
                    </div>
                    <div class="col-sm-6">
                        <input type="email" placeholder="* Email"/>
                    </div>
                    <div class="default-button text-right"><input type="submit" value="SUBMIT"/></div>
                </form>
            </div>
            </div>
        </div>
        <div class="container-fluid footer-logo pd-0">
        <div class="default-container">
            <a href="index.php"><img src="images/logo-lined.png"/></a>
            <ul class="footer-nav">
                <li><a href="#">SHOP</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="contact.php">CONTACT</a></li>
                <li><a href="stockists.php">STOCKISTS</a></li>
                <li><a href="terms-conditions.php">TERMS + CONDITIONS</a></li>
                <li><a href="shipping-policy.php">SHOPPING POLICY</a></li>
            </ul>
        </div>
        </div>
        
        
        
        
        
        <div class="container-fluid copyright pd-0">
            <div class="row pd-0">
            <div class="col-sm-12 pd-0 copyright-content">
                <span>Copyright 2017 Herk Accessories</span>
                <span>Website design by Smack Bang Designs</span>
            </div>
            </div>
        </div>
        
    </footer>
    
    
</div>
</body>
</html>