<!DOCTYPE HTML>
<html>
<head>
<title>HERK-Contact</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/scrolling-slider-data.css">
<link rel="stylesheet" href="style.css"/>

    <script>
        $(document).ready(function(){
            
            $(".retailer-container").css({"width":"50px"});
            $(".show-retailer").click(function(){
                $(".retailer-container").animate({
                    "width":"790"
                }, 200);
                $(".retailer-container form").show();
                $("#btn-close").show();
            });
            $("#btn-close").click(function(){
                $(".retailer-container form").hide();
                $(".retailer-container").animate({
                    "width":"50px"
                }, 200);
                $(this).hide();
            });
            
		});
    </script>
    
</head>
<body>
<div class="page-container">
    
    <div class="retailer-container page-home">
        <h5 class="show-retailer">BECOME A RETAILER</h5>
        <div id="btn-close">X</div>
        <form>
            <ul>
                <li><input type="text" placeholder="* Name" /></li>
                <li><input type="email" placeholder="* Email" /></li>
                <li><input type="text" placeholder="* Company Name" /></li>
                <li><input class="col-sm-6" type="email" placeholder="* Phone" />
                <input class="col-sm-6" type="email" placeholder="* Location" /></li>
                
                <li><textarea placeholder="* Comments" ></textarea></li>
                <li><div class="default-button text-right"><input value="SUBMIT" type="submit"></div></li>
            </ul>
        </form>
    </div>
    
<!--start header-->
    <div class="container-fluid pd-0">
        
        <script>
            $(document).ready(function(){
                $(".search-top").click(function(){
                    $("#search-box").toggle();
                });
            });
        </script>
        <ul class="pull-right top-nav">
            <li><input id="search-box" type="text"/></li>
            <li class="search-top"><a href="#"><img src="images/search-icon-small.png"/></a></li>
            <li><a href="#"><img src="images/mail-icon-small.png"/></a></li>
            <li><a href="#"><img src="images/user-icon-small.png"/></li>
            <li><a href="#"><img src="images/basket-icon-small.png"/> <sup>0</sup></a></li>
        </ul>
        
    </div>
    <div class="container-fluid pd-0 menu-container">
        
        <div class="logo"><a href="index.php"><img src="images/logo-black.png"/></a></div>
        <div class="main-menu">
            <ul class="menu">
                <li><a href="#">SHOP</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="contact.php">CONTACT</a></li>
                <li><a href="stockists.php">STOCKISTS</a></li>
            </ul>
        </div>
    </div>
<!--end header-->
    <div class="clearfix"></div>
    
    
        <div class="default-container1 rel">
            <h1 class="contact-rotate">CONTACT US</h1>
            <div class="contact">
                <p class="head">LET'S CHAT</p>
                <p class="desc">Whether you want to talk about our products or wanting to become a retailer, we would love for you to get in touch with us.</p>
                
                <div class="chat-form-contaienr">
                    <form>
                        <ul class="chat-form">
                            <li><input type="text" placeholder="* Full Name"/></li>
                            <li><input type="text" placeholder="* Retailer Enquiry"/></li>
                            <li><input type="text" placeholder="* Company"/></li>
                            <li><input type="email" placeholder="* Email"/></li>
                            <li><input type="text" placeholder="* Subject"/></li>
                            <li><textarea placeholder="* Message"></textarea></li>
                        </ul>
                        <div class="default-button text-right"><input value="SUBMIT" type="submit"></div>
                    </form>
                
                </div>
                
                
            </div>
        </div>
    
    
    
    
    <div class="clearfix"></div>
    <footer>
        <div class="container-fluid news-letter pd-0">
            <div class="default-container">
            <div class="row mrg-0">
                <p>SIGN UP TO OUR NEWSLETTER</p>
                <form>
                    <div class="col-sm-6">
                        <input type="text" placeholder="* Name"/>
                    </div>
                    <div class="col-sm-6">
                        <input type="email" placeholder="* Email"/>
                    </div>
                    <div class="default-button text-right"><input type="submit" value="SUBMIT"/></div>
                </form>
            </div>
            </div>
        </div>
        <div class="container-fluid footer-logo pd-0">
        <div class="default-container">
            <a href="index.php"><img src="images/logo-lined.png"/></a>
            <ul class="footer-nav">
                <li><a href="#">SHOP</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="contact.php">CONTACT</a></li>
                <li><a href="stockists.php">STOCKISTS</a></li>
                <li><a href="terms-conditions.php">TERMS + CONDITIONS</a></li>
                <li><a href="shipping-policy.php">SHOPPING POLICY</a></li>
            </ul>
        </div>
        </div>
        
        
        
        
        
        <div class="container-fluid copyright pd-0">
            <div class="row pd-0">
            <div class="col-sm-12 pd-0 copyright-content">
                <span>Copyright 2017 Herk Accessories</span>
                <span>Website design by Smack Bang Designs</span>
            </div>
            </div>
        </div>
        
    </footer>
    
    
</div>
</body>
</html>